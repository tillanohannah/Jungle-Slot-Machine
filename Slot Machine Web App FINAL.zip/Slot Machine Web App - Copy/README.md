Name: Sharmain A. Jacob
      Hannah A. Tillano
      

Project Title: Slot Machine
Theme: Jungle

Features Implemented:

- Slot machine gameplay
- Randomly generated symbols
- Score tracking system
- Win/Lose messages
- Play Again option
- Lucky Spin
- Auto Spin
- Reset Game
- Light Mode and Dark Mode
- Fullscreen mode
- Footer section